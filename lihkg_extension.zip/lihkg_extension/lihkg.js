



//chrome.storage.local.set({ key: [] })


if(window.location.href.search(".lihkg.com")!=-1){
	let str2 = `<button id="btn1234" style="z-index:99999; position: fixed; top: 80%;right:3%; background-color:red; color:white ; padding:12px">dislike</button>`
	let body = document.getElementsByTagName("body")[0]
	let head = document.getElementsByTagName("head")[0]

 	var lihkgBanList;
			body.insertAdjacentHTML("afterbegin", str2);
			document.getElementById('btn1234').onclick= addBanList;
			function addBanList() {
				document.getElementById("1").querySelectorAll('input[type=checkbox]')[1].click()
				let pathArr = window.location.pathname.split('/');
				lihkgBanList.push(pathArr[2])
				chrome.storage.local.set({ key: lihkgBanList })
				test222()
				document.getElementById("leftPanel").querySelectorAll('a[href*="/thread/'+pathArr[2]+'"]')[0].parentElement.parentElement.parentElement.style.display = 'none'
					//	alert(lihkgBanList)
				//location.reload();
			}
	function sleeper(ms) {
	  return function(x) {
		return new Promise(resolve => setTimeout(() => resolve(x), ms));
	  };
}
	chrome.storage.local.get(["key"]).then(sleeper(500)).then((result) => {
		if(result.key)
			//chrome.storage.local.set({ key: [] })
			lihkgBanList = result.key;
		else 
			lihkgBanList = [];

		test222()
		const  leftPanel = document.getElementById("leftPanel");
		  leftPanel.onclick  = test222
		var sheet = document.createElement('style')
		var style_str ="";
		if(lihkgBanList)
		for(let  i = 0 ; i<lihkgBanList.length ; i++){
			style_str += 'a[href*="/thread/'+lihkgBanList[i]+'"]{visibility: hidden;}  '
		}
		sheet.innerHTML = style_str;
		document.head.appendChild(sheet);
		//  const i_menu = document.querySelectorAll('i[class="i-menu"]')[0];
		//  i_menu.onclick  = test222
		
	});

	
	function test222(){
		let nameBanList = [];
		chrome.storage.local.get(["key"]).then(sleeper(200)).then((result) => {
			let pathArr = window.location.pathname.split('/');
			//alert(pathArr[2])
			if(pathArr[1]== "thread"){
				document.getElementById('btn1234').style.display = 'inline'
			}
			else 
				document.getElementById('btn1234').style.display = 'none'
		if(result.key)
			//chrome.storage.local.set({ key: [] })
			lihkgBanList = result.key;
		else 
			lihkgBanList = [];
		if(lihkgBanList)
			lihkgBanList.forEach(function(banItem){
				nameBanList[banItem] = true;
			})
		});


		var postLink = '';	
		// Select the node that will be observed for mutations
		var targetNode = document.getElementById('app');

		// Options for the observer (which mutations to observe)
		const config = { attributes: true, childList: true, subtree: true };

		// Callback function to execute when mutations are observed
		const callback = function(mutationsList, observerLihkg) {
			// Use traditional 'for loops' for IE 11
			for(const mutation of mutationsList) {
				if (mutation.type === 'childList') {
					
					for(var j=0; j<mutation.addedNodes.length; ++j) {	
						if( mutation.addedNodes[j].nodeType ==1 &&
						 mutation.addedNodes[j].attributes &&
						 mutation.addedNodes[j].children &&
						 mutation.addedNodes[j].children[0] &&
						 mutation.addedNodes[j].children[0].children &&
						 mutation.addedNodes[j].children[0].children[1] &&
						 mutation.addedNodes[j].children[0].children[1].children &&
						 mutation.addedNodes[j].children[0].children[1].children[1]
						 )
						 {
						//	console.log(mutation.addedNodes[j].children[0].children[0].innerHTML);
						//	console.log(mutation.addedNodes[j].children[0].children[1].children[1].href);
							postLink = mutation.addedNodes[j].children[0].children[1].children[1].href;
							if(postLink){
								//console.log(postLink.split("/")[4]);
								if(postLink.split("/")[4]){
									if(nameBanList[postLink.split("/")[4]]){
									//	alert(mutation.addedNodes[j].children[0].children[1].children[1].innerHTML)
										//if(mutation.addedNodes[j].attributes)
										//console.log(mutation.addedNodes[j].ownerDocument)
										mutation.addedNodes[j].style.display = "none";
										//mutation.addedNodes[j].children[0].remove();
										
										//mutation.addedNodes[j].parentNode.removeChild(mutation.addedNodes[j])
									}
								}
							}
						}
						
					}
					
					
				}
				else if (mutation.type === 'attributes') {
				//    console.log('The ' + mutation.attributeName + ' attribute was modified.');

				}
			}
			
		};

		// Create an observer instance linked to the callback function
		const observerLihkg = new MutationObserver(callback);

		// Start observing the target node for configured mutations
		observerLihkg.observe(targetNode, config);
	}
	
}

